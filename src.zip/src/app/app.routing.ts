import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { VisitorInformationComponent } from './visitor-information/visitor-information.component';
import { DatatableComponent } from './datatable/datatable.component';
import { ExportComponent } from './export/export.component';


const appRoutes: Routes = [
  { path: '', redirectTo: 'visitor-Information', pathMatch: 'full' },
  { path: 'visitor-Information', component: VisitorInformationComponent },
  { path: 'DataTable', component: DatatableComponent },
  { path: 'export', component: ExportComponent }
];

export const routing = RouterModule.forRoot(appRoutes);

