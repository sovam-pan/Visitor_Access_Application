import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable, from } from 'rxjs';
import { Visitor } from '../visitor.model';
@Injectable({
  providedIn: 'root'
})
export class ApphttpService {

  baseUrl: any;
  arrSelectedRowsIDs: [10];
  constructor(
    private http: HttpClient
  ) {
    this.baseUrl = environment.baseUrl;
    this.arrSelectedRowsIDs = [10];
  }

  getVisitor(): Observable<any> {
    return this.http.get(this.baseUrl + 'visitor-list');
  }
  getDeptNames(): Observable<any> {
    return this.http.get(this.baseUrl + 'dept_list');
  }
  getLocNames(): Observable<any> {
    return this.http.get(this.baseUrl + 'loc_list');
  }
  getVisitorTypeNames(): Observable<any> {
    return this.http.get(this.baseUrl + 'vistype_list');
  }
  getManagerview(): Observable<any> {
    return this.http.get(this.baseUrl + 'managerlist');
  }
  getReasonNames(): Observable<any> {
    return this.http.get(this.baseUrl + 'reasons_list');
  }

  addVisitor(visitor: Visitor) {
    console.log("Profile Object in addVisitor method: ", visitor);
    return this.http.post(this.baseUrl + 'save-visitor', visitor);
  }
  updateById(data, status) {
    for (let i = 0; i < data.length; i++) {
      data[i].approverComments = status;
      return this.http.put(`${this.baseUrl}/edit/${data[i].visitorId}`, data[i]);
    }
    return;
  }
  getManagerview1(data) {
    //return this.http.get(`${this.baseUrl}/generate/${data[0].visitor_id}`,data);
    return this.http.get(`${this.baseUrl}generateExcel`, data);
  }
  // getVisitorByID(selectedRows){
  //   this.arrSelectedRowsIDs = selectedRows.map(row => row.visitorId);
  //   console.log('arrSelectedRowsIDs--------- ', this.arrSelectedRowsIDs)
  //   return this.http.get(`${this.baseUrl}/generate?id=${arrSelectedRowsIDs}`,selectedRows);
  //   //return this.http.get(`${this.baseUrl}generateExcel`,selectedRows);
  //   // return this.arrSelectedRowsIDs;
  // }
  getSelectedVisitorList(selectedRowsIDs) {
    // Remove from local storage.
    return this.http.get(`${this.baseUrl}/generate?id=${selectedRowsIDs}`, selectedRowsIDs);
  }
}
