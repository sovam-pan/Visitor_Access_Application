import { TestBed } from '@angular/core/testing';

import { ApphttpService } from './apphttp.service';

describe('ApphttpService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ApphttpService = TestBed.get(ApphttpService);
    expect(service).toBeTruthy();
  });
});
