import { Component, OnInit, TemplateRef } from '@angular/core';
import { Validators, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ActivatedRoute, Router } from '@angular/router';
import { Visitor } from '../visitor.model';
import { ApphttpService } from '../services/apphttp.service';

@Component({
  selector: 'app-visitor-information',
  templateUrl: './visitor-information.component.html',
  styleUrls: ['./visitor-information.component.scss']
})
export class VisitorInformationComponent implements OnInit {
  submitted = false;
  profileForm: FormGroup;
  modalRef: BsModalRef | null;
  // types = ['Full Time', 'Part Time', 'Consultation'];
  //depts = ['APPS', 'ITO', 'BPO'];
  //odcs = ['Bangalore', 'Hyderabad', 'Pune', 'Mumbai'];
  message: string;
  display: string;
  temp: object;
  public searchTxt: any;
  public searchText: string;
  public data: any;
  public depts: any[];
  types: any;
  odcs: any;
  minDate: Date;
  maxDate: Date;
  minDate1: Date;
  maxDate1: Date;
  reasons: any;
  constructor(private fb: FormBuilder,
    private modalService: BsModalService,
    private router: Router,
    private apphttp: ApphttpService
  ) {

    this.profileForm = this.fb.group({
      visitorTypeId: ['', Validators.required],
      deptId: ['', Validators.required],
      visitorId: ['', Validators.required],
      visitorName: ['', Validators.required],
      locationId: ['', Validators.required],
      additionMaterial: [''],
      visitorEmailId: ['', [Validators.required, Validators.email]],
      reasonId: ['', Validators.required],
      accessReqTill: ['', Validators.required],
      accessReqFrom: ['', Validators.required],
      authorizedEscort: [''],

    });

    this.minDate = new Date();
    this.maxDate = new Date();
    this.minDate1 = new Date();
    this.maxDate1 = new Date();
    // this.minDate.setDate(this.minDate.getDate() + );
    /* 
      Which will check the current date and time.
      if time is > 2 PM return 1
        else return 0
    */
    this.minDate.setDate(this.minDate.getDate() + 0);
    this.maxDate.setDate(this.maxDate.getDate() + 6);
    this.minDate1.setDate(this.minDate.getDate() + 0);
    this.maxDate1.setDate(this.maxDate.getDate() + 6);
  }

  ngOnInit() {
    console.warn(this.profileForm.value);
    this.data = [{ 'EmpId': '1', 'name': 'Sovam Pan', 'location': 'Bangalore', 'ReqFrom': '2019-11-01', 'ReqTill': '2020-11-01', 'Reason': 'KT', 'UserEmailID': 'sovam.pan@mphasis.com', 'VisitorType': 'Full Time', 'AccessApprovalStatus': 'Done', 'CreatedBY': 'Sovam', 'AdditionalMaterial': 'Nathing', 'ApproverComments': 'Good', 'JPMCVisitorApprovalAction': 'Done', 'Department': 'APPS', 'AuthorizedEscort': '2020', 'ModifiedBy': 'Sovam Pan', 'Modified': 'Done' },
    { 'EmpId': '2', 'name': 'Kota Sindhuri', 'location': 'Bangalore', 'ReqFrom': '2019-11-01', 'ReqTill': '2020-11-01', 'Reason': 'KT', 'UserEmailID': 'sovam.pan@mphasis.com', 'VisitorType': 'Full Time', 'AccessApprovalStatus': 'Done', 'CreatedBY': 'Sovam', 'AdditionalMaterial': 'Nathing', 'ApproverComments': 'Good', 'JPMCVisitorApprovalAction': 'Done', 'Department': 'APPS', 'AuthorizedEscort': '2020', 'ModifiedBy': 'Sovam Pan', 'Modified': 'Done' },
    { 'EmpId': '3', 'name': 'Tejasree M', 'location': 'Bangalore', 'ReqFrom': '2019-11-01', 'ReqTill': '2020-11-01', 'Reason': 'KT', 'UserEmailID': 'sovam.pan@mphasis.com', 'VisitorType': 'Full Time', 'AccessApprovalStatus': 'Done', 'CreatedBY': 'Sovam', 'AdditionalMaterial': 'Nathing', 'ApproverComments': 'Good', 'JPMCVisitorApprovalAction': 'Done', 'Department': 'APPS', 'AuthorizedEscort': '2020', 'ModifiedBy': 'Sovam Pan', 'Modified': 'Done' },
    { 'EmpId': '4', 'name': 'Gurjeet', 'location': 'Bangalore', 'ReqFrom': '2019-11-01', 'ReqTill': '2020-11-01', 'Reason': 'KT', 'UserEmailID': 'sovam.pan@mphasis.com', 'VisitorType': 'Full Time', 'AccessApprovalStatus': 'Done', 'CreatedBY': 'Sovam', 'AdditionalMaterial': 'Nathing', 'ApproverComments': 'Good', 'JPMCVisitorApprovalAction': 'Done', 'Department': 'APPS', 'AuthorizedEscort': '2020', 'ModifiedBy': 'Sovam Pan', 'Modified': 'Done' },
    { 'EmpId': '5', 'name': 'Anmol', 'location': 'Kolkata', 'ReqFrom': '2019-11-01', 'ReqTill': '2020-11-01', 'Reason': 'KT', 'UserEmailID': 'sovam.pan@mphasis.com', 'VisitorType': 'Full Time', 'AccessApprovalStatus': 'Done', 'CreatedBY': 'Sovam', 'AdditionalMaterial': 'Nathing', 'ApproverComments': 'Good', 'JPMCVisitorApprovalAction': 'Done', 'Department': 'APPS', 'AuthorizedEscort': '2020', 'ModifiedBy': 'Sovam Pan', 'Modified': 'Done' },
    { 'EmpId': '6', 'name': 'Niranjan', 'location': 'Bangalore', 'ReqFrom': '2019-11-01', 'ReqTill': '2020-11-01', 'Reason': 'KT', 'UserEmailID': 'sovam.pan@mphasis.com', 'VisitorType': 'Full Time', 'AccessApprovalStatus': 'Done', 'CreatedBY': 'Sovam', 'AdditionalMaterial': 'Nathing', 'ApproverComments': 'Good', 'JPMCVisitorApprovalAction': 'Done', 'Department': 'APPS', 'AuthorizedEscort': '2020', 'ModifiedBy': 'Sovam Pan', 'Modified': 'Done' },
    { 'EmpId': '7', 'name': 'Soham', 'location': 'Bangalore', 'ReqFrom': '2019-11-01', 'ReqTill': '2020-11-01', 'Reason': 'KT', 'UserEmailID': 'sovam.pan@mphasis.com', 'VisitorType': 'Full Time', 'AccessApprovalStatus': 'Done', 'CreatedBY': 'Sovam', 'AdditionalMaterial': 'Nathing', 'ApproverComments': 'Good', 'JPMCVisitorApprovalAction': 'Done', 'Department': 'APPS', 'AuthorizedEscort': '2020', 'ModifiedBy': 'Sovam Pan', 'Modified': 'Done' }
    ];

    //  this.apphttp.getVisitors().subscribe(resp => {
    //    console.log('>> getVisitors: ', resp);   
    //  })

    this.apphttp.getDeptNames().subscribe(resp => {
      this.depts = resp;
      console.log('>> getDeptNames: ', resp);
    },
      error => console.error(error));

    this.apphttp.getLocNames().subscribe(resp => {
      this.odcs = resp;
      console.log('>> getLocNames: ', resp);
    },
      error => console.error(error));

    this.apphttp.getVisitorTypeNames().subscribe(resp => {
      this.types = resp;
      console.log('>> getVisTypeNames: ', resp);
    },
      error => console.error(error));

    this.apphttp.getReasonNames().subscribe(resp => {
      this.reasons = resp;
      console.log('>> getReasonNames: ', resp);
    },
      error => console.error(error));

  }

  get f() {
    return this.profileForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.profileForm.invalid) {
      return;
    }
    this.message = 'Confirmed!';
    this.modalRef.hide();
    //this.profileForm.reset();
    this.router.navigate(['/visitor-Information']);
    // TODO: Use EventEmitter with form value
    //console.warn(this.profileForm.value);
    //alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.profileForm.value))

    this.apphttp.addVisitor(this.profileForm.value)
      .subscribe(
        resp => {
          this.router.navigate(['/DataTable']);
          console.log('>> addVisitor: ', resp)
        },
        error => {
          error => console.log('error in addvisitor - ' + error)
        });
  }

  openModalWithClass(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(
      template,
      Object.assign({ animated: true, backdrop: 'static' }, { class: 'gray modal-lg' })
    );
    // reset form on opening
    /*
   * visitorId":30,"additionalmaterial":null,"accessrequiredfrom":null,"accessrequiredtill":null,
   * "nameControl":null,"odcControl":null,"deptControl":null,"reasonControl":null,"typeControl":null,"emailControl":null
   * */
    this.profileForm.reset({
      visitorTypeId: '',
      deptId: '',
      visitorId: '',
      visitorName: '',
      locationId: '',
      visitorEmailId: '',
      reasonId: '',
      additionMaterial: '',
      accessReqTill: '',
      accessReqFrom: '',
      authorizedEscort: ''

    });
  }
  closeFirstModal() {
    this.modalRef.hide();
    this.modalRef = null;
    this.display = 'none';
  }

}
