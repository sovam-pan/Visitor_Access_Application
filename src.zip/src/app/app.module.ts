import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AngularFontAwesomeModule } from 'angular-font-awesome';

import { routing } from './app.routing';
import { AppComponent } from './app.component';
import { VisitorInformationComponent } from './visitor-information/visitor-information.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { ModalModule } from 'ngx-bootstrap/modal';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { DatatableComponent } from './datatable/datatable.component';
// import {MultiSelectAllModule} from '@syncfusion/ej2-angular-dropdowns';
// import { CheckBoxModule, ButtonModule } from '@syncfusion/ej2-angular-buttons';
import {ExportComponent} from './export/export.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';


@NgModule({
  declarations: [
    AppComponent,
    VisitorInformationComponent, DatatableComponent, ExportComponent
  ],
  imports: [
    Ng2SmartTableModule,
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    routing,
    AngularFontAwesomeModule,
    FormsModule,
    BsDropdownModule.forRoot(),
    BsDatepickerModule.forRoot(),
    ModalModule.forRoot(),
    BrowserAnimationsModule,
    
    // MultiSelectAllModule,
    // CheckBoxModule,
    // ButtonModule,
    NgMultiSelectDropDownModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { 

  
}
