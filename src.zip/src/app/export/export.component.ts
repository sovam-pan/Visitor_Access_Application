import { Component,  OnInit } from '@angular/core';

import { IDropdownSettings } from 'ng-multiselect-dropdown';

@Component({
  selector: 'app-export',
  templateUrl: './export.component.html',
  styleUrls: ['./export.component.scss']

})

export class ExportComponent implements OnInit {

  
   maxDate: Date;
  dropdownList = [];
  selectedItems = [];
  dropdownSettings :IDropdownSettings;

    constructor() { 
      this.maxDate = new Date();
    }
    
    ngOnInit(){
        // this.myDateValue = new Date();

        this.dropdownList = [
            { item_id: 1, item_text: 'Approved' },
            { item_id: 2, item_text: 'Rejected' },
            { item_id: 3, item_text: 'in progress' },
        
          ];
        
          this.dropdownSettings = {
            singleSelection: false,
            idField: 'item_id',
            textField: 'item_text',
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            itemsShowLimit: 3,
           
          };
    }

    onItemSelect(item: any) {
        console.log(item);
      }
      onSelectAll(items: any) {
        console.log(items);
      }

      // myDateValue: Date;
      // onDateChange(newDate: Date) {
      //   console.log(newDate);
      // }
}

   
