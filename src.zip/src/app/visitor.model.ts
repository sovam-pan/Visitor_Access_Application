export class Visitor {
    locationName: String;
    deptName:String;
    reasonName:String;
    visitorType:String;
    
    visitorTypeId: number;
    reasonId: number;
    locationId: number;
    deptId: number;
    statusId:number;

    visitorId: number;
    visitorName: string;
    visitorEmailId: string;
    accessReqTill: Date;
    accessReqFrom : Date;

    additionMaterial: string;
    authorizedEscort:string;

    modifiedStatus:String;
    modifiedDate:Date;
    modifiedBy:String;
    approverComments:String;
    visitorApprovalAction:String;
    createdDate:Date;

}
