import { Component, OnInit, ViewChild } from '@angular/core';
import { ApphttpService } from '../services/apphttp.service';
import { map } from 'rxjs/operators';
import { Validators, FormBuilder } from '@angular/forms';
//import { SSL_OP_CIPHER_SERVER_PREFERENCE } from 'constants';
@Component({
  selector: 'app-datatable',
  templateUrl: './datatable.component.html',
  styleUrls: ['./datatable.component.scss']
})
export class DatatableComponent implements OnInit {
  @ViewChild('staticModal', { static: true }) staticModal;
  data: any;
  filteredData = [];
  selectedRows: any;
  arrSelectedRowsIDs: [2];
  isSubmitted: true;

  constructor(private apphttp: ApphttpService, private fb: FormBuilder) { }

  ngOnInit() {

    // 
    //get Location Names
    this.apphttp.getLocNames().subscribe(resp => {
      console.log('>>getLocNames:', resp)
      let settings = this.settings;
      settings.columns.locationName.editor.list = resp.map(ln => {
        return { title: ln.value, value: ln.key };
      });
      this.settings = Object.assign({}, settings);
    },
      error => console.error(error));

    //get Department Names
    this.apphttp.getDeptNames().subscribe(resp => {
      console.log('>>getDeptNames:', resp)
      let settings = this.settings;
      settings.columns.deptName.editor.list = resp.map(ln => {
        return { title: ln.value, value: ln.key };
      });
      this.settings = Object.assign({}, settings);
    },
      error => console.error(error));

    //get reason Names
    this.apphttp.getReasonNames().subscribe(resp => {
      console.log('>>getReasonNames:', resp)
      let settings = this.settings;
      settings.columns.reasonName.editor.list = resp.map(ln => {
        return { title: ln.value, value: ln.key };
      });
      this.settings = Object.assign({}, settings);
    },
      error => console.error(error));

    //get visitor types
    this.apphttp.getVisitorTypeNames().subscribe(resp => {
      console.log('>>getVisitorTypeNames:', resp)
      let settings = this.settings;
      settings.columns.visitorTypeName.editor.list = resp.map(ln => {
        return { title: ln.value, value: ln.key };
      });
      this.settings = Object.assign({}, settings);
    },
      error => console.error(error));

    //get manager view
    this.apphttp.getManagerview().subscribe(resp => {
      this.data = resp;
      this.filteredData = this.data;

      for (let i = 0; i <= this.data.length; i++) {

        this.filteredData[i]['deptName'] = this.settings.columns.deptName.editor.list.filter(ln => {
          if (ln.value === resp[i].deptId) {
            return ln.title;
          }
        })[0].title;

        this.filteredData[i]['reasonName'] = this.settings.columns.reasonName.editor.list.filter(ln => {
          if (ln.value === resp[i].reasonId) {
            return ln.title
          }
        })[0].title;
        this.filteredData[i]['locationName'] = this.settings.columns.locationName.editor.list.filter(ln => {
          if (ln.value === resp[i].locationId) {
            return ln.title;
          }
        }
        )[0].title;
        this.filteredData[i]['visitorTypeName'] = this.settings.columns.visitorTypeName.editor.list.filter(ln => {
          if (String(ln.value) === resp[i].visitorTypeId) {
            return ln.title;
          }
        })[0].title;
        console.log('>> getManagerview: ', resp);
        console.log('>> getManagerview: ', this.filteredData);
      }
    },


      error => console.error(error));


  }

  // New function which will do the filter the data came from sever.
  checkRange = (item) => {
    console.log('Called from Fetch Button!');
    /* if (item.date <= max && item.date >= min) {
      return item;
    } */
  }

  filterData = () => {
    this.filteredData = this.data.filter(item => this.checkRange(item));
    // Filter it again if Status also mentioned in filter parameters
  }

  // 
  settings = {
    selectMode: 'multi',
    edit: {
      editButtonContent: 'EDIT ',
      saveButtonContent: 'SAVE ',
      cancelButtonContent: 'CANCEL ',
      confirmSave: true,
    },
    actions: {
      add: false,
      delete: false,
      edit: false,
      columnTitle: 'Actions',
      position: 'left'
    },
    columns: {
      visitorId: {
        title: 'visitor_id',
        filter: false,
        editable: false,
      },
      visitorName: {
        title: 'visitor_name',
        editable: false,
      },
      visitorEmailId: {
        title: 'visitor_email_id',
        editable: false,
      },
      deptName: {
        title: 'dept_name',
        editable: false,
        editor: {
          list: [
          ],
        }
      },
      reasonName: {
        title: 'reason_name',
        editable: false,
        editor: {
          list: [
          ],
        }
      },
      locationName: {
        title: 'location_name',
        editable: false,
        editor: {
          list: [
          ],
        }
      },
      visitorTypeName: {
        title: 'visitor_type',
        editable: false,
        editor: {
          list: [
          ],
        }
      },
      additionMaterial: {
        title: 'addition_material',
        editable: false,
      },
      accessReqFrom: {
        title: 'access_req_from',
        editable: false,
      },
      accessReqTill: {
        title: 'access_req_till',
        editable: false,
      },
      approverComments: {
        title: 'approver_comments',
      },
      accessApprovalStatus: {
        title: 'access_approval_status',
        editable: false,
      },
      modifiedBy: {
        title: 'modified_by',
        editable: false,
      },
      createdBy: {
        title: 'created_by',
        editable: false,
      },
      createdDate: {
        title: 'created_date',
        editable: false,
      },
      modifiedDate: {
        title: 'modified_date',
        editable: false,
      },
      authorizedEscort: {
        title: 'authorized_escort',
        editable: false,
      },
    },
    pager:
    {
      display: true,
      perPage: 5,
      class: '',
      doEmit: false
    },
    attr: {
      class: 'table table-striped table-bordered table-hover'
    },
    defaultStyle: true
  }

  onCreateConfirm(event) {
    console.log("Create Event In Console")
    console.log(event);
    event.confirm.resolve();
  }
  onEditConfirm(event) {
    console.log("onEditConfirm(event)");
  }
  onSaveConfirm(event) {
    console.log("Edit Event In Console")
    console.log(event);
    event.confirm.resolve();
    //   this.apphttp.updateById(event.newData).subscribe(resp => {

    //   },
    //     error => console.error());
  }



  exportAsXLSX(event) {
    console.log('exportAsXLSX: ', event);
    if (this.arrSelectedRowsIDs.length) {
      this.apphttp.getSelectedVisitorList(this.arrSelectedRowsIDs).subscribe(resp => {
        console.log('>> getVisitorByID: ', resp);
        console.log('Selected Rows:--- ', this.selectedRows);
      })
    }
    else {
      this.apphttp.getManagerview1(event.data).subscribe(resp => {
        console.log('>> getManagerview1: ', resp);
        console.log(this.selectedRows);
      })
    }
  }
  onRowSelect(event) {
    this.selectedRows = event.selected;
    console.log("RowSelect In Console")
    console.log(event);
    this.arrSelectedRowsIDs = this.selectedRows.map(row => row.visitorId);
    // add to local storage
  }
  registrationForm = this.fb.group({
    approver_comments: ['', [Validators.required]]
  })

  // Getter method to access form control
  get myForm() {
    return this.registrationForm.get('approver_comments');
  }

  // Submit Registration Form
  // onSubmit() {
  //   this.isSubmitted = true;
  //   if (!this.registrationForm.valid) {
  //     return false;
  //   } else {
  //     // alert(JSON.stringify(this.registrationForm.value))
  //     console.log(this.registrationForm.value);
  //   }

  //   this.apphttp.updateById(this.data).subscribe(resp => {

  //   },
  //     error => console.error());
  // }

  Approve(e) {
    e.preventDefault();
    this.apphttp.updateById(this.data, 'Approved').subscribe(resp => {

    },
      error => console.error());
    console.log('Approve');
  }
  Reject(e) {
    e.preventDefault();
    this.apphttp.updateById(this.data, 'Reject').subscribe(resp => {

    },
      error => console.error());
    console.log('Reject');
  }


}




